// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Upload, Plus } from 'lucide-react';
// import { Job } from '../../../../types/jobsTypes';

// interface JobActionsProps {
//   job: Job;
// }

// const JobActions: React.FC<JobActionsProps> = ({ job }) => {
//   const navigate = useNavigate();

//   const handleDetailsClick = () => {
//     navigate(`/JobWebsite/${job.id}`);
//   };

//   const handleUploadClick = () => {
//     navigate(`/JobUpload/${job.id}`);
//   };

//   return (
//     <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
//       <button
//         onClick={handleDetailsClick}
//         style={{
//           flex: 1,
//           backgroundColor: '#2563eb',
//           color: 'white',
//           padding: '8px 16px',
//           borderRadius: '6px',
//           fontSize: '14px',
//           fontWeight: '500',
//           border: 'none',
//           cursor: 'pointer',
//           display: 'flex',
//           alignItems: 'center',
//           gap: '6px',
//           transition: 'background-color 0.2s'
//         }}
//         onMouseOver={e => (e.currentTarget.style.backgroundColor = '#1d4ed8')}
//         onMouseOut={e => (e.currentTarget.style.backgroundColor = '#2563eb')}
//       >
//         <Plus width={16} height={16} />
//         <span>לפרטים נוספים</span>
//       </button>

//       <button
//         onClick={handleUploadClick}
//         style={{
//           flex: 1,
//           backgroundColor: '#16a34a',
//           color: 'white',
//           padding: '8px 16px',
//           borderRadius: '6px',
//           fontSize: '14px',
//           fontWeight: '500',
//           border: 'none',
//           cursor: 'pointer',
//           display: 'flex',
//           alignItems: 'center',
//           gap: '6px',
//           transition: 'background-color 0.2s'
//         }}
//         onMouseOver={e => (e.currentTarget.style.backgroundColor = '#15803d')}
//         onMouseOut={e => (e.currentTarget.style.backgroundColor = '#16a34a')}
//       >
//         <Upload width={16} height={16} />
//         <span>להעלאת קורות חיים</span>
//       </button>
//     </div>
//   );
// };

// export default JobActions;


import React, { useState } from 'react';
import {Send, Upload, Plus } from 'lucide-react';
import { Job } from '../../../../types/jobsTypes';
import Modal from '../../../../globalComponents/ui/Modal'; // הנתיב לקובץ הפופאפ שלך
import JobWebsite from '../JobWebsite'; // הנתיב לקומפוננטה שמציגה את פרטי המשרה
import { useNavigate } from 'react-router-dom';
import SaveJobButton from '../addJobFicher/SaveJobButton';

interface JobActionsProps {
  job: Job;
}

const JobActions: React.FC<JobActionsProps> = ({ job }) => {
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const handleDetailsClick = () => {
    setShowDetailsModal(true);
  };

  const handleUploadClick = () => {
    // אם את רוצה גם כאן פופאפ – תוסיפי אחד נוסף.
    alert('להעלאת קו"ח – כאן אפשר לפתוח פופאפ אחר או לשלב');
  };


  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <button
          onClick={handleUploadClick}
          style={{
            backgroundColor: '#22c55e',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '20px',
            fontSize: '14px',
            fontWeight: '500',
            border: 'none',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            transition: 'background-color 0.2s'
          }}
        >
          <Send width={14} height={14} />
          <span>שלח/י קורות חיים</span>
        </button>
        
        {/* כפתור שמירה חדש */}
        <SaveJobButton job={job} size="small" />
      </div>

      <div 
        onClick={handleDetailsClick}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          cursor: 'pointer',
          color: '#f97316',
          fontSize: '14px',
          fontWeight: '500'
        }}
      >
        <Plus width={16} height={16} />
        <span>לפרטים נוספים</span>
      </div>
      <button
        onClick={handleUploadClick}
        style={{
          flex: 1,
          backgroundColor: '#16a34a',
          color: 'white',
          padding: '8px 16px',
          borderRadius: '6px',
          fontSize: '14px',
          fontWeight: '500',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          transition: 'background-color 0.2s'
        }}
        onMouseOver={e => (e.currentTarget.style.backgroundColor = '#15803d')}
        onMouseOut={e => (e.currentTarget.style.backgroundColor = '#16a34a')}
      >
        <Upload width={16} height={16} />
        <span>להעלאת קורות חיים</span>
      </button>

      {/* 🟦 Modal של פרטי משרה */}
      <Modal
        title="פרטי משרה וניתוח קורות חיים"
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
      >
        <JobWebsite id={job.id} />
      </Modal>
    </div>
  );
};

export default JobActions;
