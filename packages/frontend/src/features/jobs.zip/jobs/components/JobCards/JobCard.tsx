// קומפוננטת JOBCARD אחראית להציג כרטיס משרה
//  כלומר, היא אחראית להציג מידע של משרה אחת בצורה ברורה
import React from 'react';
import { JobCardProps } from '../../../../types/jobsTypes';
import { truncateText } from '../../../../utils/jobUtils';
import JobHeader from './JobHeader';
import JobDetails from './JobDetails';
import TechTags from './TechTags';
import JobActions from './JobActions';

const JobCard: React.FC<JobCardProps> = ({ job, onDetailsClick, onUploadCV }) => {
  return (
    <div
      style={{
        backgroundColor: 'white',
        borderRadius: '10px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        padding: '20px',
        border: '1px solid #ddd',
        transition: 'box-shadow 0.2s ease',
        marginBottom: '20px',
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
      }}
    >
      <JobHeader job={job} />
      <p
        style={{
          color: '#2563eb',
          fontWeight: 500,
          fontSize: '14px',
          marginBottom: '12px',
        }}
      >   
      </p>
      <p
        style={{
          color: '#4b5563',
          fontSize: '14px',
          marginBottom: '16px',
          lineHeight: '1.6', }} >

        {truncateText(job.description)}
      </p>
      <JobDetails job={job} />
      <TechTags requirements={job.requirements} />
      <JobActions job={job}  />
    </div>
  );
};



export default JobCard;

