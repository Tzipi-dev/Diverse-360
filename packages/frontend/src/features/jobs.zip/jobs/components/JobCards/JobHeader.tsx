import React from 'react';
import { Job } from '../../../../types/jobsTypes';

interface JobHeaderProps {
  job: Job;
}

const JobHeader: React.FC<JobHeaderProps> = ({ job }) => {
  return (
    <div style={{ 
      position: 'relative', 
      marginBottom: '12px',
      textAlign: 'center'
    }}>
      {/* כותרת המשרה - באמצע */}
      <h3 style={{ 
        fontSize: '18px', 
        fontWeight: '600', 
        color: '#1F2937', 
        lineHeight: '1.25',
        margin: 0
      }}>
        {job.title}
      </h3>

      {/* סטטוס - מימין למעלה */}
      <span style={{
        position: 'absolute',
        right: 0,
        top: 0,
        backgroundColor: job.isActive ? '#D1FAE5' : '#F3F4F6',
        color: job.isActive ? '#047857' : '#6B7280',
        fontSize: '12px',
        padding: '4px 8px',
        borderRadius: '9999px',
        fontWeight: '500',
        whiteSpace: 'nowrap'
      }}>
        {job.isActive ? 'פעילה' : 'לא פעילה'}
      </span>
    </div>
  );
};

export default JobHeader;
