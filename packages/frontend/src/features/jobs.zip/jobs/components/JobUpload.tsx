import React from 'react';
const JobUpload: React.FC = () => {
  return (
    <div>
      <h2>פרטים נוספים על המשרה</h2>
      {/* תוכן יתווסף מאוחר יותר */}
    </div>
  );
};

export default JobUpload;
