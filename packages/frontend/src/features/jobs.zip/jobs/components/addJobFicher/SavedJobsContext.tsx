import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode
} from 'react';
import { Job } from '../../../../types/jobsTypes';
import { SavedJob, SavedJobsContextType } from '../../../../types/savedJobsTypes';

const SavedJobsContext = createContext<SavedJobsContextType | undefined>(undefined);

interface SavedJobsProviderProps {
  children: ReactNode;
  userId: string; // מזהה המשתמש המחובר
}

export const SavedJobsProvider: React.FC<SavedJobsProviderProps> = ({ children, userId }) => {
  const [savedJobs, setSavedJobs] = useState<SavedJob[]>([]);
  const [loading, setLoading] = useState(false);

  const loadSavedJobs = useCallback(async () => {
    setLoading(true);
    try {
      // כאן תחליפי בקריאה לשרת שלך
      const response = await fetch(`/api/saved-job/${userId}`);
      const data = await response.json();
      setSavedJobs(data);
    } catch (error) {
      console.error('שגיאה בטעינת משרות שמורות:', error);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  // טעינת משרות שמורות מהשרת בטעינת הדף
  useEffect(() => {
    loadSavedJobs();
  }, [loadSavedJobs]);

  const saveJob = async (job: Job) => {
    try {
      const savedJob: SavedJob = {
        id: `${userId}_${job.id}`,
        jobId: job.id,
        userId,
        saved_At: new Date(),
        job
      };

      // שמירה בשרת
      await fetch('/api/saved-job', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(savedJob)
      });

      // עדכון מצב מקומי
      setSavedJobs(prev => [...prev, savedJob]);
    } catch (error) {
      console.error('שגיאה בשמירת משרה:', error);
    }
  };

  const unsaveJob = async (jobId: string) => {
    try {
      // מחיקה בשרת
      await fetch(`/api/saved-jobs/${userId}/${jobId}`, {
        method: 'DELETE'
      });

      // עדכון מצב מקומי
      setSavedJobs(prev => prev.filter(savedJob => savedJob.jobId !== jobId));
    } catch (error) {
      console.error('שגיאה במחיקת משרה:', error);
    }
  };

  const isJobSaved = (jobId: string): boolean => {
    return savedJobs.some(savedJob => savedJob.jobId === jobId);
  };

  return (
    <SavedJobsContext.Provider
      value={{
        savedJobs,
        saveJob,
        unsaveJob,
        isJobSaved,
        loading
      }}
    >
      {children}
    </SavedJobsContext.Provider>
  );
};

export const useSavedJobs = () => {
  const context = useContext(SavedJobsContext);
  if (!context) {
    throw new Error('useSavedJobs must be used within SavedJobsProvider');
  }
  return context;
};

