// import React, { useState } from 'react';
// import { useParams } from 'react-router-dom';
// import {
//   useUploadResumeMutation,
//   useAnalyzeResumeMutation,
//   useGenerateCoverLetterMutation,
// } from '../resumeApi';

// const JobWebsite = () => {
//   const { id } = useParams<{ id: string }>();

//   const [selectedFile, setSelectedFile] = useState<File | null>(null);
//   const [uploading, setUploading] = useState(false);
//   const [analyzing, setAnalyzing] = useState(false);
//   const [uploadSuccess, setUploadSuccess] = useState(false);
//   const [analyzeSuccess, setAnalyzeSuccess] = useState(false);
//   const [error, setError] = useState<string | null>(null);
//   const [analysisResult, setAnalysisResult] = useState<string | null>(null);

//   // סטייטים ופונקציה למכתב מקדים
//   const [generatingCoverLetter, setGeneratingCoverLetter] = useState(false);
//   const [coverLetter, setCoverLetter] = useState<string | null>(null);
//   const [isModalOpen, setIsModalOpen] = useState(false);


//   const [uploadResume] = useUploadResumeMutation();
//   const [analyzeResume] = useAnalyzeResumeMutation();
//   const [generateCoverLetter] = useGenerateCoverLetterMutation();

//   const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     const file = event.target.files?.[0];
//     if (file) {
//       setSelectedFile(file);
//       setUploadSuccess(false);
//       setAnalyzeSuccess(false);
//       setError(null);
//       setAnalysisResult(null);
//       setCoverLetter(null); // ננקה גם מכתב מקדים קיים כשמשנים קובץ
//     }
//   };

//   const handleAnalyze = async () => {
//     if (!selectedFile) {
//       setError('נא לבחור קובץ');
//       return;
//     }

//     setAnalyzing(true);
//     setError(null);
//     setAnalyzeSuccess(false);

//     try {
//       const formData = new FormData();
//       formData.append('file', selectedFile);

//       const res = await analyzeResume(formData).unwrap();
//       setAnalysisResult(res.analysis);
//       setAnalyzeSuccess(true);
//     } catch (err) {
//       console.error(err);
//       setError('שגיאה בניתוח הקובץ');
//     }

//     setAnalyzing(false);
//   };

//   const handleUpload = async () => {
//     if (!selectedFile || !id) {
//       setError('יש לבחור קובץ וקיים מזהה משרה');
//       return;
//     }

//     setUploading(true);
//     setError(null);
//     setUploadSuccess(false);

//     try {
//       const formData = new FormData();
//       formData.append('file', selectedFile);
//       formData.append('job_id', id);

//       await uploadResume(formData).unwrap();
//       setUploadSuccess(true);
//     } catch (err) {
//       console.error(err);
//       setError('שגיאה בהעלאת הקובץ');
//     }

//     setUploading(false);
//   };

//   // פונקציה חדשה למכתב מקדים
//   // const handleGenerateCoverLetter = async () => {
//   //   if (!selectedFile || !id) {
//   //     setError('נא לבחור קובץ ומשרה.');
//   //     return;
//   //   }
//   //   setGeneratingCoverLetter(true);
//   //   setError(null);

//   //   try {
//   //     const formData = new FormData();
//   //     formData.append('file', selectedFile);
//   //     formData.append('job_id', id);

//   //     const res = await generateCoverLetter(formData).unwrap();
//   //     setCoverLetter(res.content);
//   //   } catch (err) {
//   //     console.error(err);
//   //     setError('שגיאה ביצירת מכתב מקדים');
//   //   }

//   //   setGeneratingCoverLetter(false);
//   // };
// const handleGenerateCoverLetter = async () => {
//   if (!selectedFile || !id) {
//     setError('נא לבחור קובץ ומשרה.');
//     return;
//   }
//   setGeneratingCoverLetter(true);
//   setError(null);

//   try {
//     const formData = new FormData();
//     formData.append('file', selectedFile);
//     formData.append('job_id', id);

//     const res = await generateCoverLetter(formData).unwrap();
//     setCoverLetter(res.content);
//     setIsModalOpen(true); // נפתח את המודל לאחר יצירת המכתב
//   } catch (err) {
//     console.error(err);
//     setError('שגיאה ביצירת מכתב מקדים');
//   }

//   setGeneratingCoverLetter(false);
// };
//   return (
//     <div style={{ padding: '2rem', maxWidth: '700px', margin: '0 auto', textAlign: 'center' }}>
//       <h2 style={{ color: '#d0006f' }}>פרטי משרה</h2>

//       <div style={{ marginBottom: '2rem' }}>
//         <h3>מפתח/ת תוכנה</h3>
//         <p>עבודה מהבית, בשעות ערב</p>
//         <p>ניסיון נדרש: 3 שנים בפיתוח תוכנה</p>
//       </div>

//       <div style={{ marginBottom: '1rem' }}>
//         <h4>העלאת קובץ קורות חיים</h4>
//         <input 
//           type="file" 
//           accept=".pdf,.doc,.docx"
//           onChange={handleFileChange}
//         />
//       </div>

//       <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', marginTop: '1rem' }}>
//         <button
//           onClick={handleAnalyze}
//           disabled={analyzing || !selectedFile}
//           style={{
//             backgroundColor: '#0077cc',
//             color: 'white',
//             padding: '0.6rem 1.2rem',
//             border: 'none',
//             borderRadius: '4px',
//             cursor: 'pointer',
//           }}
//         >
//           {analyzing ? 'מנתח...' : 'נתח קובץ עם AI'}
//         </button>

//         <button
//           onClick={handleUpload}
//           disabled={uploading || !selectedFile}
//           style={{
//             backgroundColor: '#d0006f',
//             color: 'white',
//             padding: '0.6rem 1.2rem',
//             border: 'none',
//             borderRadius: '4px',
//             cursor: 'pointer',
//           }}
//         >
//           {uploading ? 'מעלה...' : 'שלח קובץ למשרה'}
//         </button>

//         <button
//           onClick={handleGenerateCoverLetter}
//           disabled={generatingCoverLetter || !selectedFile}
//           style={{
//             backgroundColor: '#d0006f',
//             color: 'white',
//             padding: '0.6rem 1.2rem',
//             border: 'none',
//             borderRadius: '4px',
//             cursor: 'pointer',
//           }}
//         >
//           {generatingCoverLetter ? 'מייצר...' : 'צור מכתב מקדים עם AI'}
//         </button>
//       </div>

//       {analyzeSuccess && (
//         <p style={{ color: 'green', marginTop: '1rem' }}>
//           הניתוח הסתיים בהצלחה!
//         </p>
//       )}

//       {uploadSuccess && (
//         <p style={{ color: 'green', marginTop: '1rem' }}>
//           הקובץ הועלה בהצלחה!
//         </p>
//       )}

//       {analysisResult && (
//         <div style={{ marginTop: '2rem', textAlign: 'right' }}>
//           <h4>תוצאה מה-AI:</h4>
//           <pre style={{ background: '#f5f5f5', padding: '1rem', borderRadius: '4px' }}>
//             {analysisResult}
//           </pre>
//         </div>
//       )}

//       {/* {coverLetter && (
//         <div style={{ marginTop: '2rem', textAlign: 'right', whiteSpace: 'pre-wrap', background: '#eee', padding: '1rem', borderRadius: '4px' }}>
//           <h4>מכתב מקדים שנוצר:</h4>
//           {coverLetter}
//         </div>
//       )} */}




//       {error && (
//         <p style={{ color: 'red', marginTop: '1rem' }}>{error}</p>
//       )}
//     </div>
//   );
// };

// export default JobWebsite;
import React, { useState, useRef, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  useUploadResumeMutation,
  useAnalyzeResumeMutation,
  useGenerateCoverLetterMutation,
} from '../resumeApi';

import { useGetJobByIdQuery } from '../jobsApi';
import CoverLetterModal from './CoverLetterModal';


type JobWebsiteProps = {
  id: string;
};

const JobWebsite = ({ id }: JobWebsiteProps) => {

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [analyzeSuccess, setAnalyzeSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const [generatingCoverLetter, setGeneratingCoverLetter] = useState(false);
  const [coverLetter, setCoverLetter] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [uploadResume] = useUploadResumeMutation();
  const [analyzeResume] = useAnalyzeResumeMutation();
  const [generateCoverLetter] = useGenerateCoverLetterMutation();

  const {
    data: job,
    isLoading,
    isError,
  } = useGetJobByIdQuery(id!, { skip: !id });

  useEffect(() => {
    if (analyzeSuccess && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [analyzeSuccess]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setUploadSuccess(false);
      setAnalyzeSuccess(false);
      setError(null);
      setAnalysisResult(null);
      setCoverLetter(null);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedFile) {
      setError('נא לבחור קובץ');
      return;
    }

    setAnalyzing(true);
    setError(null);
    setAnalyzeSuccess(false);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      const res = await analyzeResume(formData).unwrap();
      setAnalysisResult(res.analysis);
      setAnalyzeSuccess(true);
    } catch (err) {
      console.error(err);
      setError('שגיאה בניתוח הקובץ');
    }

    setAnalyzing(false);
  };

  const handleUpload = async () => {
    if (!selectedFile || !id) {
      setError('יש לבחור קובץ וקיים מזהה משרה');
      return;
    }

    setUploading(true);
    setError(null);
    setUploadSuccess(false);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('job_id', id);

      await uploadResume(formData).unwrap();
      setUploadSuccess(true);
    } catch (err) {
      console.error(err);
      setError('שגיאה בהעלאת הקובץ');
    }

    setUploading(false);
  };

  const handleGenerateCoverLetter = async () => {
    if (!selectedFile || !id) {
      setError('נא לבחור קובץ ומשרה.');
      return;
    }
    setGeneratingCoverLetter(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('job_id', id);

      const res = await generateCoverLetter(formData).unwrap();
      setCoverLetter(res.content);
      setIsModalOpen(true);
    } catch (err) {
      console.error(err);
      setError('שגיאה ביצירת מכתב מקדים');
    }

    setGeneratingCoverLetter(false);
  };

  return (
    <div style={{ padding: '1rem', maxWidth: '700px', margin: '0 auto', textAlign: 'center' }}>
    <h2 style={{ color: '#d0006f' }}>פרטי משרה</h2>
    {isLoading && <p>טוען פרטי משרה...</p>}
    {isError && <p style={{ color: 'red' }}>שגיאה בטעינת פרטי המשרה</p>}
    {job && (
      <div style={{ marginBottom: '2rem' }}>
        <h3>{job.title}</h3>
        <p>{job.location}</p>
        <p>{job.requirements}</p>
      </div>
    )}
      <div style={{ marginBottom: '1rem' }}>
        <h4>העלאת קובץ קורות חיים</h4>
        <input 
          type="file" 
          accept=".pdf,.doc,.docx"
          onChange={handleFileChange}
        />
      </div>

      <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', marginTop: '1rem' }}>
        <button
          onClick={handleAnalyze}
          disabled={analyzing || !selectedFile}
          style={{
            backgroundColor: '#d0006f',
            color: 'white',
            padding: '0.6rem 1.2rem',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          {analyzing ? 'מנתח...' : 'נתח קובץ עם AI'}
        </button>

        <button
          onClick={handleGenerateCoverLetter}
          disabled={generatingCoverLetter || !selectedFile}
          style={{
            backgroundColor: '#d0006f',
            color: 'white',
            padding: '0.6rem 1.2rem',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          {generatingCoverLetter ? 'מייצר...' : 'צור מכתב מקדים עם AI'}
        </button>

        <button
          onClick={handleUpload}
          disabled={uploading || !selectedFile}
          style={{
            backgroundColor: '#d0006f',
            color: 'white',
            padding: '0.6rem 1.2rem',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          {uploading ? 'מעלה...' : 'שלח קובץ למשרה'}
        </button>
      </div>

      {analyzeSuccess && (
        <p style={{ color: '#d0006f', marginTop: '1rem' }}>
          הניתוח הסתיים בהצלחה!
        </p>
      )}

      {uploadSuccess && (
        <p style={{ color: '#d0006f', marginTop: '1rem' }}>
          הקובץ הועלה בהצלחה!
        </p>
      )}

      {analysisResult && (
  <div
    ref={resultRef}
    style={{
      marginTop: '2rem',
      textAlign: 'right',
      background: '#f5f5f5',
      padding: '1rem',
      borderRadius: '8px',
      direction: 'rtl',
      fontFamily: 'Arial, sans-serif',
      whiteSpace: 'pre-wrap',
      wordBreak: 'break-word',
    }}
  >
    <h4 style={{ marginBottom: '1rem', color: '#333' }}>תוצאה מה-AI:</h4>
    {analysisResult}
  </div>
)}




      {error && (
        <p style={{ color: 'red', marginTop: '1rem' }}>{error}</p>
      )}

      {isModalOpen && coverLetter && (
        <CoverLetterModal
          content={coverLetter}
          onClose={() => setIsModalOpen(false)}
          onChange={(newContent) => setCoverLetter(newContent)}
          jobTitle="מכתב מקדים"
        />
      )}
    </div>
  );
};

export default JobWebsite;