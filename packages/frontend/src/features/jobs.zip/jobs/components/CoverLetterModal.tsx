import React from "react";
import PrimaryButton from "../../../globalComponents/ui/PrimaryButton";

import { printCoverLetter } from "../../../utils/printCoverLetter";


interface CoverLetterModalProps {
  content: string;
  onClose: () => void;
  onChange: (newContent: string) => void;
  jobTitle: string;
}

const CoverLetterModal: React.FC<CoverLetterModalProps> = ({
  content,
  onClose,
  onChange,
  jobTitle,
}) => {
  return (
    <div
      style={{
        position: "fixed",
        top: "0",
        right: "0",
        bottom: "0",
        left: "0",
        backgroundColor: "rgba(0,0,0,0.4)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 999,
      }}
    >
      <div
        style={{
          backgroundColor: "white",
          padding: "2rem",
          borderRadius: "12px",
          width: "80%",
          maxHeight: "80%",
          overflowY: "auto",
          direction: "rtl",
        }}
      >
        <h2 style={{ marginBottom: "1rem" }}>טיוטת מכתב מקדים</h2>
        <textarea
          value={content}
          onChange={(e) => onChange(e.target.value)}
          style={{
            width: "100%",
            height: "200px",
            padding: "1rem",
            direction: "rtl",
            fontSize: "16px",
            lineHeight: "1.6",
            marginBottom: "1rem",
          }}
        />
        <div style={{ display: "flex", gap: "1rem" }}>
        <PrimaryButton onClick={() => printCoverLetter(content, jobTitle)}>
  הדפס / תצוגה
</PrimaryButton>

          <PrimaryButton onClick={onClose}>סגור</PrimaryButton>
        </div>
      </div>
    </div>
  );
};

export default CoverLetterModal;
