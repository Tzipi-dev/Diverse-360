
import React, { useEffect, useState } from "react"
import { Job } from "../../../types/jobsTypes"


interface SearchBarProps {
  jobs: Job[]
  onSearchResults: (results: Job[]) => void
}

const SearchBar: React.FC<SearchBarProps> = ({ jobs, onSearchResults }) => {
  const [notFound, setNotFound] = useState(false)
  const [userSearch, setUserSearch] = useState("")
  const [field, setField] = useState("")
  const [jobType, setJobType] = useState("")
  const [location, setLocation] = useState("")
  const [dateFrom, setDateFrom] = useState("")

  useEffect(() => {
    const normalizedTerm = userSearch.trim().toLowerCase()

    let filtered = [...jobs]

    if (normalizedTerm) {
      filtered = filtered.filter((job) =>
        job.title.toLowerCase().includes(normalizedTerm)
      )
    }

    if (field) {
      filtered = filtered.filter((job) => job.description.includes(field))
    }

    if (jobType) {
      filtered = filtered.filter((job) => job.requirements.includes(jobType))
    }

    if (location) {
      filtered = filtered.filter((job) => job.location === location)
    }

    if (dateFrom) {
      filtered = filtered.filter(
        (job) => new Date(job.createdAt) >= new Date(dateFrom)
      )
    }

    onSearchResults(filtered)
    setNotFound(filtered.length === 0)
  }, [userSearch, field, jobType, location, dateFrom, jobs, onSearchResults])

  const resetFilters = () => {
    setUserSearch("")
    setField("")
    setJobType("")
    setLocation("")
    setDateFrom("")
  }

  const containerStyle: React.CSSProperties = {
    display: "flex",
    flexWrap: "wrap",
    gap: "12px",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "12px",
    color: "var(--color-primary)",
  }

  const inputStyle: React.CSSProperties = {
    padding: "8px 12px",
    borderRadius: "6px",
    border: "1px solid #ccc",
    fontSize: "14px",
    minWidth: "150px",
    flexGrow: 1,
  }

  const selectStyle: React.CSSProperties = {
    padding: "8px 12px",
    borderRadius: "6px",
    border: "1px solid #ccc",
    fontSize: "14px",
    minWidth: "140px",
  }

  const buttonStyle: React.CSSProperties = {
    padding: "8px 16px",
    backgroundColor: "var(--color-primary)",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "14px",
  
  }

  const notFoundStyle: React.CSSProperties = {
    color: "red",
    marginTop: "8px",
  }

  return (
    <div>
      <style>
      </style>
      <div style={containerStyle}>
        <input
          type="text"
          placeholder="חיפוש לפי שם משרה..."
          value={userSearch}
          onChange={(e) => setUserSearch(e.target.value)}
          style={inputStyle}
        />

        <select value={field} onChange={(e) => setField(e.target.value)} style={selectStyle}>
          <option value="">בחר תחום</option>
          <option value="פיתוח">פיתוח</option>
          <option value="עיצוב">עיצוב</option>
          <option value="שיווק">שיווק</option>
        </select>

        <select value={jobType} onChange={(e) => setJobType(e.target.value)} style={selectStyle}>
          <option value="">בחר סוג משרה</option>
          <option value="מלאה">משרה מלאה</option>
          <option value="חלקית">משרה חלקית</option>
          <option value="פרילנס">פרילנס</option>
        </select>

        <select value={location} onChange={(e) => setLocation(e.target.value)} style={selectStyle}>
          <option value="">בחר מיקום</option>
          {Array.from(new Set(jobs.map((job) => job.location))).map((loc) => (
            <option key={loc} value={loc}>
              {loc}
            </option>
          ))}
        </select>

        <input
          type="date"
          value={dateFrom}
          onChange={(e) => setDateFrom(e.target.value)}
          style={inputStyle}
        />

        <button onClick={resetFilters} style={buttonStyle}>
          איפוס
        </button>
      </div>

      {notFound && <p style={notFoundStyle}>לא נמצאו משרות מתאימות לפי הנתונים שהוזנו.</p>}
    </div>
  )
}

export default SearchBar







