import apiSlice from "../../app/apiSlice";

const resumeApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    uploadResume: builder.mutation<void, FormData>({
      query: (formData) => ({
        url: "/api/resumes/upload",
        method: "POST",
        body: formData,
      }),
      invalidatesTags: ["Resume"],
    }),

    getResumesByJob: builder.query<{ url: string }[], string>({
      query: (jobId) => `/resumes/${jobId}`,
      providesTags: ["Resume"],
    }),

    analyzeResume: builder.mutation<{ analysis: string }, FormData>({
      query: (formData) => ({
        url: "/api/analyze-resume",
        method: "POST",
        body: formData,
      }),
    }),

generateCoverLetter: builder.mutation<{ content:string }, FormData>({
  query: (formData) => ({
    url: '/api/coverLetter',
    method: 'POST',
    body: formData,
  }),
})


  }),

});

export const {
  useUploadResumeMutation,
 // useGetResumesByJobQuery,
  useAnalyzeResumeMutation,
  useGenerateCoverLetterMutation,
} = resumeApi;

export default resumeApi;