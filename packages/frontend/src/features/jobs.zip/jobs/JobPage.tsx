
import React, { useState, useEffect } from "react";
import { useGetAllJobsQuery } from "./jobsApi";
import JobCard from "./components/JobCards/JobCard";
import JobFilters from "./components/JobFilters";
import { Job } from "../../types/jobsTypes";
import SavedJobsPage from "./components/addJobFicher/SavedJobsPage";
import { Bookmark, Sparkles } from "lucide-react";
import { useSavedJobs } from "./components/addJobFicher/SavedJobsContext";
import ResumeUploadModal from "./components/resumeUploadModal";
import SuggestedJobsList from "./components/suggestedJobsList";

const JobPage: React.FC = () => {
  const { data: allJobs = [] } = useGetAllJobsQuery();
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([]);
  const [showSavedJobs, setShowSavedJobs] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestedJobs, setSuggestedJobs] = useState<Job[]>([]);

  const { savedJobs } = useSavedJobs();

  useEffect(() => {
    setFilteredJobs(allJobs);
  }, [allJobs]);

  return (
    <div style={{ padding: "1rem", position: "relative" }}>
      {/* כותרת + כפתורים */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ direction: "rtl", color: "var(--color-primary)" }}>
          לוח משרות לבוגרות DiversTech
        </h1>

        <div style={{ display: "flex", gap: "10px" }}>
          {/* כפתור התאמה לפי קורות חיים */}
          <button
            onClick={() => setShowSuggestions(true)}
            style={{
              background: "#fff0f5",
              border: "1px solid #f472b6",
              borderRadius: "8px",
              padding: "8px 12px",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              cursor: "pointer"
            }}
          >
            <Sparkles size={18} color="#e83e8c" />
            <span style={{ color: "#e83e8c", fontWeight: 500 }}>התאם לי משרות</span>
          </button>

          {/* כפתור משרות שמורות */}
          <button
            onClick={() => setShowSavedJobs(!showSavedJobs)}
            style={{
              background: "#f9fafb",
              border: "1px solid #e5e7eb",
              borderRadius: "8px",
              padding: "8px 12px",
              display: "flex",
              alignItems: "center",
              cursor: "pointer",
              gap: "8px"
            }}
          >
            <Bookmark size={18} color="#2563eb" />
            <span style={{ color: "#2563eb", fontWeight: 500 }}>משרות שמורות</span>
            {savedJobs.length > 0 && (
              <span style={{
                backgroundColor: '#ef4444',
                color: 'white',
                borderRadius: '9999px',
                padding: '2px 6px',
                fontSize: '12px',
                fontWeight: 'bold'
              }}>
                {savedJobs.length}
              </span>
            )}
          </button>
        </div>
      </div>

      <JobFilters jobs={allJobs} onSearchResults={setFilteredJobs} />

      {filteredJobs.map((job) => (
        <JobCard key={job.id} job={job} />
      ))}

      {/* הצגת משרות מותאמות לפי קורות חיים */}
      <SuggestedJobsList jobs={suggestedJobs} />

      {/* מודאל: העלאת קורות חיים */}
      {showSuggestions && (
        <ResumeUploadModal
          onClose={() => setShowSuggestions(false)}
          onJobsSuggested={(jobs) => setSuggestedJobs(jobs)}
        />
      )}

      {/* מודאל משרות שמורות */}
      {showSavedJobs && (
        <div style={{
          position: "fixed",
          top: 0, left: 0, width: "100vw", height: "100vh",
          background: "rgba(0,0,0,0.3)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 1000
        }}>
          <div style={{
            background: "white",
            padding: "20px",
            borderRadius: "12px",
            maxWidth: "90%",
            maxHeight: "90%",
            overflowY: "auto",
            position: "relative"
          }}>
            <button
              onClick={() => setShowSavedJobs(false)}
              style={{
                position: "absolute", top: "10px", right: "10px",
                background: "none", border: "none", fontSize: "18px", cursor: "pointer"
              }}
              aria-label="סגור"
            >
              ❌
            </button>
            <SavedJobsPage />
          </div>
        </div>
      )}
    </div>
  );
};

export default JobPage;
