export interface Job {  
    id: string
    title: string
    description: string
    location: string
    requirements: string
    createAt: Date
    isActive: boolean
    workMode: string

}

export interface JobCardProps {
  job: Job;
  onDetailsClick: (job: Job) => void;
  onUploadCV: (job: Job, file: File) => void;
}

export interface CoverLetter {
  title: string; // כותרת להצגה, למשל "מכתב למשרת React Developer"
  content: string; // גוף המכתב
  jobId: string;
  resumeFileName?: string;
}
